# autothumb
automatic thumbnail maker
# Setup
1. npm install
2. npm start